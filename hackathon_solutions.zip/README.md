Solution to the Hackathon problems.
